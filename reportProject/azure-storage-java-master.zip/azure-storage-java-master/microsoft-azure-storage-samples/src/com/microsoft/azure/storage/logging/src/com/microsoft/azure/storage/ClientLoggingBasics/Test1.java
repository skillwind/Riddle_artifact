package com.microsoft.azure.storage.ClientLoggingBasics;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.node.TextNode;
import com.fasterxml.jackson.databind.node.TreeTraversingParser;
import com.microsoft.azure.storage.core.EncryptionData;

public class Test1 {
	public static void main(String[] args) throws JsonParseException, IOException {
		
		TreeTraversingParser parser = new TreeTraversingParser(JsonNode());
		EncryptionData.deserialize(parser);
//		EncryptionData.deserialize((TreeTraversingParser)null);
	}
	public static com.fasterxml.jackson.databind.JsonNode JsonNode() {
		return new TextNode("{ Ètest") ;
		
	}
	public static com.fasterxml.jackson.core.Base64Variant Base64Variant(){
		return null;
	}
}
