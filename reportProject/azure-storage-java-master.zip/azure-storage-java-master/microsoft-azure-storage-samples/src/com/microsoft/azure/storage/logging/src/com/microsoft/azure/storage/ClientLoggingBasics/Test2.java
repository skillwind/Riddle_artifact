package com.microsoft.azure.storage.ClientLoggingBasics;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParseException;
import com.microsoft.azure.storage.core.EncryptionData;

public class Test2 {
	public static void main(String[] args) throws JsonParseException, IOException {
		EncryptionData.deserialize("");
	}
}
