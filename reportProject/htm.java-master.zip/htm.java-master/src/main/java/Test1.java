import java.io.ByteArrayInputStream;
import java.io.IOException;

import org.numenta.nupic.Parameters;
import org.nustaq.serialization.FSTConfiguration;
import org.nustaq.serialization.FSTObjectInput;

public class Test1 {
	public static void main(String[] args) throws IOException, Exception {
		Parameters.getAllDefaultParameters().readForNetwork(FSTObjectInput());
	}

	public static FSTObjectInput FSTObjectInput() throws IOException, Exception {
		byte[] bArr ="{ ".getBytes();
		FSTObjectInput fSTObjectInput = new org.nustaq.serialization.FSTObjectInput(new ByteArrayInputStream(bArr),
				FSTConfiguration());
		return fSTObjectInput;
	}

	public static FSTConfiguration FSTConfiguration() {
		FSTConfiguration conf = FSTConfiguration.createJsonConfiguration(false, false);
		return conf;
	}
}
