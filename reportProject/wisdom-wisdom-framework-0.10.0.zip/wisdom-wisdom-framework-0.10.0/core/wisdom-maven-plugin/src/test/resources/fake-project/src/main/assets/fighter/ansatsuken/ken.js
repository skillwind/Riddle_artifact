var name = "ken.js";
console.log("Ken joins the fight!");