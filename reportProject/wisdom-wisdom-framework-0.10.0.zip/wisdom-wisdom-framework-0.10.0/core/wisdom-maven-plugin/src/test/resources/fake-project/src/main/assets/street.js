var msg = "Here comes a new challenger";
console.log(msg);