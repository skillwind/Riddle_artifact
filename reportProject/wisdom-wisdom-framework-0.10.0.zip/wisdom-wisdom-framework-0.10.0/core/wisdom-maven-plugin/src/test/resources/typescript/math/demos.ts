///<reference path="./interfaces.d.ts" />

import { MathDemo } from "./impl/math_demo";

var math = new MathDemo();
console.log(math.pow(2, 2));
console.log(math.PI);
