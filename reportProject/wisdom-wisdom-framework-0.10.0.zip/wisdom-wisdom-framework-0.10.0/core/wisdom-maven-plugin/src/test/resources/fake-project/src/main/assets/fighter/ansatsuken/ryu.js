var name = "ryu";
console.log("Ken joins the fight!");