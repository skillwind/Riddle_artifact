// Keep it empty
// Does not compile on purpose (test error computation)
var math = new MathDemo();
console.log(math.pow(2, x));
console.log(math.PI);
