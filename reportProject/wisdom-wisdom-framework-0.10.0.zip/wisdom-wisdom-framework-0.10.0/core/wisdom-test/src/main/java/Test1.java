import org.osgi.framework.BundleException;
import org.wisdom.test.internals.ChameleonExecutor;

public class Test1 {
	public static void main(String[] args) throws BundleException {
		ChameleonExecutor.deployApplication();
	}
}
