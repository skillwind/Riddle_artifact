package org.stjs.command.line;

public class Test1 {
	public static void main(String[] args) {
		com.google.javascript.rhino.JSDocInfo info = new com.google.javascript.rhino.JSDocInfo();
		info.toStringVerbose();
	}
}
