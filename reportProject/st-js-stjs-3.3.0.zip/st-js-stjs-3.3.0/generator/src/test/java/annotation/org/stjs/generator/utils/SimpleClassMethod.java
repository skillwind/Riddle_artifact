package annotation.org.stjs.generator.utils;

import org.stjs.generator.utils.Annotations.Annotation3;

abstract public class SimpleClassMethod {
	@Annotation3("abc")
	abstract public void method(String a, int b);
}
