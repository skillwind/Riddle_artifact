package annotation.org.stjs.generator.utils;

import org.stjs.generator.utils.Annotations.Annotation2;

abstract public class SimpleClass {
	@Annotation2("abc")
	abstract public void method(String a, int b);
}
