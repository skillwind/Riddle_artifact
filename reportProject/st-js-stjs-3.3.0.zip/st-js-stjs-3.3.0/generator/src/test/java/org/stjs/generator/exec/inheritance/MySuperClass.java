package org.stjs.generator.exec.inheritance;

public class MySuperClass {
	protected int field;

}
