package org.stjs.generator.writer.annotations;

public class Annotation3 {
	@MyAnnotations.WithMultipleValues(n = 2, m = "100")
	public int field;
}
