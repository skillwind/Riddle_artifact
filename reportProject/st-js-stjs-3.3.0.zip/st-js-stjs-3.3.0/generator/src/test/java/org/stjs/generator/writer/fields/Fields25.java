package org.stjs.generator.writer.fields;

import org.stjs.javascript.annotation.Template;

public class Fields25 {
	@Template("property")
	public int field;

	public static void main(String[] args) {
		Fields25 obj = new Fields25();
		int n = obj.field;
	}

}
