package org.stjs.generator.deps;

public class Dep6Child extends Dep6Parent {

}
