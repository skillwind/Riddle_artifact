package org.stjs.generator.writer.innerTypes;

public class InnerTypes10 {

	private class InnerClass {
		private final MyBean p;

		public InnerClass(MyBean p) {
			this.p = p.find("");
		}
	}
}
