package org.stjs.generator.lib.number;

public class Number2 {
	public static int main(String[] args) {
		return new Double(123.4).intValue();
	}
}
