package org.stjs.generator.writer.fields;

import org.stjs.javascript.annotation.Template;

public class Fields15 {

	@Template("property")
	public String field;

	public void method(String n) {
		field = n;
	}

	public void set(String field, Object value) {
	}
}
