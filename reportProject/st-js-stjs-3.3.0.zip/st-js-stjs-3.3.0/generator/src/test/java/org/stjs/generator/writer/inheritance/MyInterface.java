package org.stjs.generator.writer.inheritance;

public interface MyInterface {

}
