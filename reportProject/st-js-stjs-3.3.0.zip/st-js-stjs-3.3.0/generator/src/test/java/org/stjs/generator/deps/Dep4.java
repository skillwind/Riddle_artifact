package org.stjs.generator.deps;

public class Dep4 {
	public class Child1 extends Dep1 {

	}
}
