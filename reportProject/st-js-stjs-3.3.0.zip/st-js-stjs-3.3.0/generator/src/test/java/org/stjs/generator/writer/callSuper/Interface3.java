package org.stjs.generator.writer.callSuper;

public interface Interface3 {
	public void instanceMethod(String arg);
}
