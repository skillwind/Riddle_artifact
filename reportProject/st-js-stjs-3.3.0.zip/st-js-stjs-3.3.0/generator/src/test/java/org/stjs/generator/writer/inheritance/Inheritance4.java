package org.stjs.generator.writer.inheritance;

public interface Inheritance4 extends MyInterface, MyInterface2 {

}
