package org.stjs.generator.writer.callSuper;

public class CallSuper8 extends SuperClass {
	public CallSuper8(int x) {
		int y = x;
	}
}
