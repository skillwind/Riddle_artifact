package org.stjs.generator.writer.innerTypes;

import org.stjs.javascript.functions.Callback0;

public class InnerTypes12 {
	private final boolean ok = false;

	public InnerTypes12() {
		if (ok) {
			Callback0 c = new Callback0() {
				@Override
				public void $invoke() {
				}
			};
		}

	}
}