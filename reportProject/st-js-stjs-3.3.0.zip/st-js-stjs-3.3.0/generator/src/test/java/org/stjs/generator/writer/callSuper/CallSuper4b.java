package org.stjs.generator.writer.callSuper;

public class CallSuper4b extends SuperClass3 {
	public void instanceMethod2(String arg) {
		instanceMethod(arg);
	}
}
