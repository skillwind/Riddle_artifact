package org.stjs.generator.writer.annotations;

import javax.annotation.concurrent.Immutable;

@Immutable
public class Annotation1 {

}
