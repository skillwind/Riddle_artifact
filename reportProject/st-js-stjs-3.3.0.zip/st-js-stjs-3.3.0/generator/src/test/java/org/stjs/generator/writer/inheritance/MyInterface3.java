package org.stjs.generator.writer.inheritance;

public interface MyInterface3<T> {

}
