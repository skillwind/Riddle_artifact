package org.stjs.generator.writer.inheritance;

public class MyClass1 {
	public static class MyInnerClass {

	}
}
