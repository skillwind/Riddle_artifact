package org.stjs.generator.writer.callSuper;

public class SuperClass2 {
	public String instanceField;
	public static String staticField;

	public SuperClass2(String arg) {
		//
	}

	public void instanceMethod(String arg) {

	}

	public static void staticMethod(String arg) {

	}
}
