package org.stjs.generator.writer.globalScope;

public class GlobalScope9 {
	public void test() {
		@SuppressWarnings("unused")
		String s = org.stjs.generator.writer.globalScope.Globals.field;
	}
}
