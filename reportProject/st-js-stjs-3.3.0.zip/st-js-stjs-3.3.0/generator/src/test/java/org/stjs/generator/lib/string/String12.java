package org.stjs.generator.lib.string;

public class String12 {
	public static boolean main(String[] args) {
		return "abca".regionMatches(1, "bc", 0, 2);
	}
}
