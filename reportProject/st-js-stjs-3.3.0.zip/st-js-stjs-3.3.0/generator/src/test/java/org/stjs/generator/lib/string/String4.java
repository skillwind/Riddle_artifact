package org.stjs.generator.lib.string;

public class String4 {
	public static boolean main(String[] args) {
		return "aaabc".matches("a+bc");
	}
}
