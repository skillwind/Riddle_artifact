package org.stjs.generator.writer.fields;

public class Fields13 {
	private final boolean value = false;

	public boolean isValue() {
		return value;
	}

	public void method(Boolean b) {
		method(isValue());
	}
}
