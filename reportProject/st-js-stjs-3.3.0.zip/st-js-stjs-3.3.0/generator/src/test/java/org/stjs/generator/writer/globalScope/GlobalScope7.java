package org.stjs.generator.writer.globalScope;

import static org.stjs.generator.writer.globalScope.Globals.*;

public class GlobalScope7 {
	public void test() {
		int n = method();
	}
}
