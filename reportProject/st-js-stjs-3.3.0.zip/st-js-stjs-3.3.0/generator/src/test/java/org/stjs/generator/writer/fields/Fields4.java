package org.stjs.generator.writer.fields;

public class Fields4 {
	public static final int x = 2;
}
