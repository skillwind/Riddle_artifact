package org.stjs.generator.deps;

public class Dep1 {
	public static class Child1 {

	}
}
