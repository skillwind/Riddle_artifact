package org.stjs.generator.deps;

public class Err1 {
	public static class Child1 extends Err2 {

	}
}
