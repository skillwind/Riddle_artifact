package org.stjs.generator.writer.inheritance;

public class Inheritance7 extends MySuperClass {
	public Inheritance7() {

	}

}
