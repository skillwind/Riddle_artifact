package org.stjs.generator.deps;

public class Dep10 {

	public int method(Dep10p p) {
		Dep10p field;
		return p.method();
	}
}
