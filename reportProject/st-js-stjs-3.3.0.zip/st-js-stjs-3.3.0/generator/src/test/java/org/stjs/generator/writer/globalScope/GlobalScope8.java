package org.stjs.generator.writer.globalScope;

import org.stjs.javascript.annotation.GlobalScope;

@GlobalScope
public class GlobalScope8 {
	public static int main(String[] args) {
		return 2;
	}
}
