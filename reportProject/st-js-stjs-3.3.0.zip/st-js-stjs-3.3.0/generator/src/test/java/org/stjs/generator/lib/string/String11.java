package org.stjs.generator.lib.string;

public class String11 {
	public static String main(String[] args) {
		return "abca".replaceFirst("a", "x");
	}
}
