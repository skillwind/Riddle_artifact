package org.stjs.generator.writer.callSuper;

public class SuperClass {
	public String instanceField;
	public static String staticField;

	public SuperClass() {
		//
	}

	public void instanceMethod(String arg) {

	}

	public static void staticMethod(String arg) {

	}
}
