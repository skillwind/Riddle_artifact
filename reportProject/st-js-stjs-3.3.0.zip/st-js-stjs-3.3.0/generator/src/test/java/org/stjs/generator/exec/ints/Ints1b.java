package org.stjs.generator.exec.ints;

public class Ints1b {
	public long method(long a) {
		return a;
	}

	public static long main(String[] args) {
		return new Ints1b().method((long) 1413492112445.3);
	}
}
