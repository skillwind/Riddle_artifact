package org.stjs.generator.writer.globalScope;

public class GlobalScope1 {
	public void test() {
		Globals.method();
	}
}
