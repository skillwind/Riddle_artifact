package org.stjs.generator.writer.inlineFunctions;

import org.stjs.javascript.annotation.JavascriptFunction;

@JavascriptFunction
public interface FunctionInterface3 {
	public void method(int arg);
}
