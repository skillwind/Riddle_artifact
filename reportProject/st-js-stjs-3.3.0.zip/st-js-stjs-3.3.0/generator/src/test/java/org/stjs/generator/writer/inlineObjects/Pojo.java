package org.stjs.generator.writer.inlineObjects;

import org.stjs.javascript.annotation.DataType;
import org.stjs.javascript.functions.Callback0;

@DataType
public class Pojo {
	public int a;
	public String b;
	public Callback0 r;
}
