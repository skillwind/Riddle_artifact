package org.stjs.generator.writer.inheritance;

import org.stjs.generator.writer.inheritance.MyClass1.MyInnerClass;

public class Inheritance8 extends MyInnerClass {

}
