package org.stjs.generator.deps;

public class Dep2 extends Dep1 {

}
