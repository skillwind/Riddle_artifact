package org.stjs.generator.deps;

public class Dep9 {
	public void method() {
		new Dep9i() {
			@Override
			public void method() {
				// do smth
			}
		};
	}
}
