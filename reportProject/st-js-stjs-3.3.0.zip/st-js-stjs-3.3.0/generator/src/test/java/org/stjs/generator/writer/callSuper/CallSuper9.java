package org.stjs.generator.writer.callSuper;

public class CallSuper9 extends SuperClass {
	private int x = 0;
}
