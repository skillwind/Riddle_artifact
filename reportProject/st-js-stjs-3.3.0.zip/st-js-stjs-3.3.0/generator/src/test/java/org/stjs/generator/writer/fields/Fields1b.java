package org.stjs.generator.writer.fields;

public class Fields1b {
	public double x;
}
