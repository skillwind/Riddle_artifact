package org.stjs.generator.exec.json;

import org.stjs.javascript.Map;

public class Class3 {
	public String type;

	public Map<String, Map<String, Class1>> map;

	public Class3() {
		this.type = "Class3";
	}
}
