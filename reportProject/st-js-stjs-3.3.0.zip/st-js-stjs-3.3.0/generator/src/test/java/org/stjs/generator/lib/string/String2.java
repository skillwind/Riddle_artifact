package org.stjs.generator.lib.string;

public class String2 {
	public static boolean main(String[] args) {
		return "abc".startsWith("bc", 1);
	}
}
