package org.stjs.generator.writer.callSuper;

public class CallSuper2 extends SuperClass2 {
	public CallSuper2(String arg) {
		super(arg);
	}
}
