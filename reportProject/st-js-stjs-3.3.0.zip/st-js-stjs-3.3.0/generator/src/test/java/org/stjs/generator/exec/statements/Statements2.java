package org.stjs.generator.exec.statements;

import org.stjs.javascript.JSObjectAdapter;

public class Statements2 {

	public static int main(String[] args) {
		Statements2 instance = new Statements2();
		if(instance.getClass() == Statements2.class){
			if(instance.getClass() == JSObjectAdapter.$constructor(instance)){
				return 0;
			}
			return 1;
		}
		return 2;
	}

}
