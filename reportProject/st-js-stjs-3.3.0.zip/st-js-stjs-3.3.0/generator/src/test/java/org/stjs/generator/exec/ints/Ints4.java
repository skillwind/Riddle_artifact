package org.stjs.generator.exec.ints;

public class Ints4 {
	public double method() {
		return 3.0 / 2 + 1;
	}

	public static double main(String[] args) {
		return new Ints4().method();
	}
}
