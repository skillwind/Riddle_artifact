package org.stjs.generator.lib.string;

public class String5 {
	public static boolean main(String[] args) {
		return "ababc".matches("a+bc");
	}
}
