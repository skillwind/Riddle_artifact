package org.stjs.generator.deps;

public class Dep10p {

	public int method() {
		return 10;
	}

}
