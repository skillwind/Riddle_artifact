package org.stjs.generator.writer.bridge;

import org.stjs.javascript.annotation.STJSBridge;

@STJSBridge
public class Bridge3 {
	public static int main(String[] args) {
		return 1;
	}
}