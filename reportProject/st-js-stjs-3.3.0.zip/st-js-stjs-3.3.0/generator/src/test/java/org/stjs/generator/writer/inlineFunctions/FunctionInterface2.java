package org.stjs.generator.writer.inlineFunctions;

public interface FunctionInterface2 {
	public void $invoke(int arg);

	public void $invoke2(int arg2);
}
