package org.stjs.generator.lib.string;

public class String3 {
	public static boolean main(String[] args) {
		return "abc".endsWith("bc");
	}
}
