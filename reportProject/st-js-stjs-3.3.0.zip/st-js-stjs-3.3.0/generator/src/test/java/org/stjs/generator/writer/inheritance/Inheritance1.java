package org.stjs.generator.writer.inheritance;

public class Inheritance1 implements MyInterface {

}
