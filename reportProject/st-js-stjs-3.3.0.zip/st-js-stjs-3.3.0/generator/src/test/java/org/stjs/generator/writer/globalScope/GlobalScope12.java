package org.stjs.generator.writer.globalScope;

import org.stjs.javascript.annotation.GlobalScope;

@GlobalScope
public class GlobalScope12 {
	public static class Inner {

	}

	public final static Inner inner = new Inner();
}
