package org.stjs.generator.writer.globalScope;

import static org.stjs.generator.writer.globalScope.Globals.field;

public class GlobalScope4 {
	public void test() {
		@SuppressWarnings("unused")
		String s = field;
	}
}
