package org.stjs.generator.writer.inheritance;

public class Inheritance3 extends MySuperClass {
	public int method() {
		return field;
	}
}
