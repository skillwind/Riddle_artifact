package org.stjs.generator.writer.fields;

public class Fields18 {

	public void method(String n) {
		Fields17 f = new Fields17();
		f.field = n;
	}

}
