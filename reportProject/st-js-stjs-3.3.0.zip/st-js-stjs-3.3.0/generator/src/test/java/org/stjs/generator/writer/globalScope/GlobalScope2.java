package org.stjs.generator.writer.globalScope;

import static org.stjs.generator.writer.globalScope.Globals.method;

public class GlobalScope2 {
	public void test() {
		method();
	}
}
