package org.stjs.generator.writer.inlineObjects.pack;

import org.stjs.javascript.functions.Callback0;

public class Pojo2 {
	public int a;
	public String b;
	public Callback0 r;
}
