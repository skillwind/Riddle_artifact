package org.stjs.generator.exec.inheritance;

public interface MyInterface extends MySuperInterface {

}
