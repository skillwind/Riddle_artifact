package org.stjs.generator.deps;

public class Dep13b {
	public static class Inner {
	}
}
