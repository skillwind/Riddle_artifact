package org.stjs.generator.writer.bridge;

public class Bridge2 {
	public void method() {
		BridgeSyntheticClass b = new BridgeSyntheticClass();
	}
}
