package org.stjs.generator.exec.json;

public class Class6 extends Class1 {
	public Inner child;

	public Class6() {
		this.type = "Class6";
	}
}
