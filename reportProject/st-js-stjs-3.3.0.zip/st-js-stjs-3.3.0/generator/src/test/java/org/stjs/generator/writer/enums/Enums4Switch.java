package org.stjs.generator.writer.enums;

public class Enums4Switch {

	public void main() {
		Enums4 x = Enums4.c;
		switch (x) {
			case a:
				break;
			case b:
				break;
		}
	}

}
