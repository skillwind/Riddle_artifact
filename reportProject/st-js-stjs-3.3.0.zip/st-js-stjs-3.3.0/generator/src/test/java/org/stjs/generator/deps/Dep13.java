package org.stjs.generator.deps;

public class Dep13 {

	static {
		Dep13b.Inner somethhing = new Dep13b.Inner();
	}
}
