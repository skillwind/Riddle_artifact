package org.stjs.generator.exec.json;

public class Class5 {

	public enum MyEnum {
		a, b
	}

	public String type;
	public int number;
	public MyEnum e;

	public Class5 child;

	public int method() {
		return 0;
	}

	public Class5() {
		this.type = "Class5";
	}
}
