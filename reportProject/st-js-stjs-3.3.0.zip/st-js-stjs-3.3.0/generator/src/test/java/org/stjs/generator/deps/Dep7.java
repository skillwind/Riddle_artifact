package org.stjs.generator.deps;

public class Dep7 {
	public String method() {
		return Dep7s.FIELD;
	}
}
