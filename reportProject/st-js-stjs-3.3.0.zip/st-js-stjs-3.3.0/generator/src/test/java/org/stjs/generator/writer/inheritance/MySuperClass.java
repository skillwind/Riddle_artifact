package org.stjs.generator.writer.inheritance;

public class MySuperClass {
	protected int field;

}
