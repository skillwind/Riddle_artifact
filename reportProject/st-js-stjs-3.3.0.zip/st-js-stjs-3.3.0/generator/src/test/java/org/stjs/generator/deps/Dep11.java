package org.stjs.generator.deps;

public class Dep11 {

	static {
		Dep11b something = new Dep11b();
	}
}
