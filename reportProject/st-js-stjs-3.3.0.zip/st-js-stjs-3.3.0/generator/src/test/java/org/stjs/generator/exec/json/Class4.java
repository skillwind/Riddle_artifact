package org.stjs.generator.exec.json;

import org.stjs.javascript.Date;

public class Class4 {
	public String type;
	public Date date;

	public Class4() {
		this.type = "Class4";
	}
}
