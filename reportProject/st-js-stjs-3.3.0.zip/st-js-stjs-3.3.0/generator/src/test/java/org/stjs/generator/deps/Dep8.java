package org.stjs.generator.deps;

public class Dep8 {
	public Dep7s method() {
		return new Dep7s();
	}
}
