package org.stjs.generator.writer.callSuper;

public class CallSuper1 {
	public CallSuper1() {
		super();
	}
}
