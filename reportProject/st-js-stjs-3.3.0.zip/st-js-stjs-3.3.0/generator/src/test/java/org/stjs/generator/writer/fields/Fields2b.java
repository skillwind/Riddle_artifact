package org.stjs.generator.writer.fields;

public class Fields2b {
	public int x = -2;
}
