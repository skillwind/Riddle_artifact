package org.stjs.generator.writer.fields;

public class Fields3 {
	public int x = 2, y = 3;
}
