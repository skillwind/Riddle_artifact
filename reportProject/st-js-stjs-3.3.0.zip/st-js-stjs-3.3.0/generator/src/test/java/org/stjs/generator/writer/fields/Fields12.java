package org.stjs.generator.writer.fields;

import static org.stjs.javascript.JSObjectAdapter.$prototype;

public class Fields12<T> {
	@SuppressWarnings("unused")
	public void method() {
		Object clazz = $prototype(String.class);
	}
}
