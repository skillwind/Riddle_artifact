package org.stjs.generator.writer.enums;

public class Enums6 {
	public enum Value {
		a, b, c;
	}

	@SuppressWarnings("unused")
	public void main() {
		for (Value v : Value.values()) {
			//
		}
	}
}
