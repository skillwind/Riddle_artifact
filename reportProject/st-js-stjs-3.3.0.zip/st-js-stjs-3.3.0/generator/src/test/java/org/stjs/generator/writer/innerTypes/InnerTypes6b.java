package org.stjs.generator.writer.innerTypes;

public class InnerTypes6b {

	public int method() {
		return 0;
	}

	class InnerType {
		public void $invoke() {
			int m = method();
		}
	}

}
