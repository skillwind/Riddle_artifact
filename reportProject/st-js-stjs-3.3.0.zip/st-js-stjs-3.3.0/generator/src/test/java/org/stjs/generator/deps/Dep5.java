package org.stjs.generator.deps;

import static org.stjs.javascript.JSGlobal.stjs;

public class Dep5 {
	public void method(Object obj) {
		boolean ok = stjs.isEnum(obj);
	}
}
