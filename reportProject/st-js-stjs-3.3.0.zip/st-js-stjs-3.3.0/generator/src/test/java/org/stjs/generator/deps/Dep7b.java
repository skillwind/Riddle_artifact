package org.stjs.generator.deps;

public class Dep7b {
	public static final Dep7s d = new Dep7s();
}
