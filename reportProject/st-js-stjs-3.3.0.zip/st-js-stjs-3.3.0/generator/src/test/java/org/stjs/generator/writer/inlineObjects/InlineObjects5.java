package org.stjs.generator.writer.inlineObjects;

public class InlineObjects5 {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Pojo o = new Pojo();
	}
}
