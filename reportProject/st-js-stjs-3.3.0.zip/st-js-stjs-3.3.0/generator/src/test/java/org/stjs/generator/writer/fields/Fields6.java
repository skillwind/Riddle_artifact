package org.stjs.generator.writer.fields;

import org.stjs.generator.writer.inlineObjects.Pojo;

public class Fields6 {
	public Pojo x = new Pojo();
}
