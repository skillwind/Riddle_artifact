package org.stjs.generator.writer.enums;

import org.stjs.javascript.annotation.Namespace;

@Namespace("my.enums")
public enum EnumsNamespace {
	A, B, C
}
