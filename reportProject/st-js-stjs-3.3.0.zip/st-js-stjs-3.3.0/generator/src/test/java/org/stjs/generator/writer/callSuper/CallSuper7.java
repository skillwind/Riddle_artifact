package org.stjs.generator.writer.callSuper;

public class CallSuper7 extends SuperClass {
	public static void staticMethod2(String arg) {
		staticMethod(arg);
	}
}
