package org.stjs.generator.writer.inlineObjects;

public class InlineObjects10 {
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		BridgePojo o = new BridgePojo() {{
			damned(12);
		}};
	}
}
