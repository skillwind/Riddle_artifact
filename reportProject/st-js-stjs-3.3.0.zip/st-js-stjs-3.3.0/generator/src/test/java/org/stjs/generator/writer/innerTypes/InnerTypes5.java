package org.stjs.generator.writer.innerTypes;

import org.stjs.generator.writer.inheritance.MySuperClass;

public class InnerTypes5 {
	class InnerType extends MySuperClass {
	}

}
