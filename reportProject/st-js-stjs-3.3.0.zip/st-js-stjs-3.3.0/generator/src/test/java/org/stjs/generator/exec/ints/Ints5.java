package org.stjs.generator.exec.ints;

public class Ints5 {
	public double method() {
		return 3 / 2.0 + 1;
	}

	public static double main(String[] args) {
		return new Ints5().method();
	}
}
