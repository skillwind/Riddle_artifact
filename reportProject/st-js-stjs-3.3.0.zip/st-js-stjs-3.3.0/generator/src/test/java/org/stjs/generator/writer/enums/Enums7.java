package org.stjs.generator.writer.enums;

public class Enums7 {

	public void main(Enums4 x) {
		switch (x) {
		case a:
			break;
		case b:
			break;
		}
	}

}
