package org.stjs.generator.deps;

public class Dep7s {
	public static final String FIELD = "a";
}
