package org.stjs.generator.writer.inheritance;

import org.stjs.javascript.annotation.SyntheticType;

@SyntheticType
public interface MyInterface4 {

}
