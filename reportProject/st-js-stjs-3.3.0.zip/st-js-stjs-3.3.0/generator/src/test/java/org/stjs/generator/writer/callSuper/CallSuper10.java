package org.stjs.generator.writer.callSuper;

public class CallSuper10 extends SuperClass {
	void method() {
		String x = super.instanceField;
	}
}
