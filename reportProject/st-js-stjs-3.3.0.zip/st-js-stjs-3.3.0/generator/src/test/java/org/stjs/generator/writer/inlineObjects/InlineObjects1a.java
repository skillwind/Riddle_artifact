package org.stjs.generator.writer.inlineObjects;

import org.stjs.generator.writer.inlineObjects.pack.Pojo2;

public class InlineObjects1a {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Pojo2 o = new Pojo2();
	}
}
