package org.stjs.generator.sourcemap;

public class Sourcemap1 {
	public void method1() {
		Sourcemap2 s = new Sourcemap2();
		s.method2(null);
	}
}
