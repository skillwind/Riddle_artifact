package org.stjs.generator.exec.json;

import org.stjs.javascript.Map;

public class Class2 {
	public String type;

	public Map<String, Class1> map;

	public Class2() {
		this.type = "Class2";
	}
}
