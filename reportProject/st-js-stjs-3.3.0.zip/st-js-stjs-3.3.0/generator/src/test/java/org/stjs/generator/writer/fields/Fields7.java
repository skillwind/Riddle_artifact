package org.stjs.generator.writer.fields;

import org.stjs.generator.writer.inlineObjects.Pojo;

public class Fields7 {
	public static Pojo x = new Pojo();
}
