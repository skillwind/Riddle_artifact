package org.stjs.generator.writer.callSuper;

public class CallSuper3 extends SuperClass {
	@Override
	public void instanceMethod(String arg) {
		super.instanceMethod(arg);
	}

}
