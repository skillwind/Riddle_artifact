package org.stjs.generator.lib.string;

public class String9 {
	public static int main(String[] args) {
		return "abc".codePointAt(1);
	}
}
