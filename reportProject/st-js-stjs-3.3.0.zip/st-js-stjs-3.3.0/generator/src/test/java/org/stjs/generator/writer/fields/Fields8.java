package org.stjs.generator.writer.fields;

public class Fields8 {
	public int x = 2;
	public int y = x;
}
