package org.stjs.generator.writer.inheritance;

public class Inheritance2 extends MySuperClass {

}
