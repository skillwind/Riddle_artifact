package org.stjs.generator.writer.bridge.pack;

public class Bridge4 {
	public static int main(String[] args) {
		return 1;
	}
}
