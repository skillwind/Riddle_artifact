package org.stjs.generator.utils;

import org.stjs.generator.utils.Annotations.Annotation1;

public class SimpleClass {
	@Annotation1("abc")
	public void method(String a, int b) {

	}
}
