package org.stjs.generator.writer.globalScope;

public class GlobalScope3 {
	public void test() {
		@SuppressWarnings("unused")
		String s = Globals.field;
	}
}
