package org.stjs.generator.deps;

public class Dep12 {
	static {
		Dep12b.Inner.newBuilder();
	}
}
