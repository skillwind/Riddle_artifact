package org.stjs.generator.writer.enums;

public enum Enums1 {
	a, b, c;
}
