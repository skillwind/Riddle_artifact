package org.stjs.generator.writer.fields;

import org.stjs.javascript.Array;

public class Fields9 {
	public Array<String> field;
}
