package org.stjs.generator.deps;

public interface Dep9i {
	void method();
}
