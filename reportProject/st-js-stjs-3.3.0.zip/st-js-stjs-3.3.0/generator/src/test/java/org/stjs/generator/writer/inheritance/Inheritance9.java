package org.stjs.generator.writer.inheritance;

public class Inheritance9 extends MySyntheticClass {

}
