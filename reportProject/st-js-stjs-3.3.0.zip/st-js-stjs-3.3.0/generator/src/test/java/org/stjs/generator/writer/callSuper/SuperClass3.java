package org.stjs.generator.writer.callSuper;

public class SuperClass3<T extends SuperClass3<?>> implements Interface3 {

	@Override
	public void instanceMethod(String arg) {

	}

}
