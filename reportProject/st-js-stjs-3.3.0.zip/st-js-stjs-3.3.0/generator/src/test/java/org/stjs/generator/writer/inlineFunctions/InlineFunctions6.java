package org.stjs.generator.writer.inlineFunctions;

public class InlineFunctions6 implements FunctionInterface {

	@Override
	public void $invoke(int arg) {
		//
	}

}
