package org.stjs.generator.writer.innerTypes;

public class InnerTypes6 {
	int n = 0;

	class InnerType {
		public void $invoke() {
			int m = n;
		}
	}

}
