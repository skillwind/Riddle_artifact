package org.stjs.generator.writer.innerTypes;

public class InnerTypes11 {

	private enum InnerEnum {
		a;
	}

}
