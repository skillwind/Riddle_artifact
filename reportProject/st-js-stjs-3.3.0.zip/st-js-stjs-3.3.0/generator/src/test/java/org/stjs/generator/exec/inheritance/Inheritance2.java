package org.stjs.generator.exec.inheritance;

import org.stjs.generator.exec.inheritance.Inheritance.C;

public class Inheritance2 {
	public static int main(String[] args) {
		C c = new C();
		return c.method1(1);
	}
}
