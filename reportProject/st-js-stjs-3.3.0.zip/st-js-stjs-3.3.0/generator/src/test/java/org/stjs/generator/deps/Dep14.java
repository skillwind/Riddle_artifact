package org.stjs.generator.deps;

public class Dep14 {
	static {
		Dep14b.newBuilder();
	}
}
