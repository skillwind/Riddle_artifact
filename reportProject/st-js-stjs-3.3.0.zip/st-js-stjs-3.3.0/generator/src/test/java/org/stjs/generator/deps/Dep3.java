package org.stjs.generator.deps;

public class Dep3 extends Dep1.Child1 {

}
