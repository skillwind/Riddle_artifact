package org.stjs.generator.deps;

public class Dep14b {
	public static void newBuilder(){
		// Do nothing
	}
}
