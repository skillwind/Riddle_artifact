package org.stjs.generator.writer.fields;

public class Fields14 {

	public static final int ONE = 1;
	public static final int TWO = ONE + 1;

	public static int main(@SuppressWarnings("unused") String[] args) {
		return TWO;
	}
}
