package org.stjs.generator.writer.annotations;

@MyAnnotations.WithMultipleValues(n = 2)
public class Annotation2 {

}
