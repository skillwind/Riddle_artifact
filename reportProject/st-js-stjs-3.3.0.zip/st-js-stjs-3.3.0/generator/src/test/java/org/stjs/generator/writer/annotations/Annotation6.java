package org.stjs.generator.writer.annotations;

import org.stjs.generator.writer.callSuper.Interface3;

public class Annotation6 implements Interface3 {

	@Override
	public void instanceMethod(String arg) {
		// TODO Auto-generated method stub

	}
}
