package org.stjs.generator.lib.string;

public class String13 {
	public static boolean main(String[] args) {
		return "abca".regionMatches(true, 1, "BC", 0, 2);
	}
}
