package org.stjs.generator.lib.number;

public class Number3 {
	public static int main(String[] args) {
		return Integer.valueOf("123");
	}
}
