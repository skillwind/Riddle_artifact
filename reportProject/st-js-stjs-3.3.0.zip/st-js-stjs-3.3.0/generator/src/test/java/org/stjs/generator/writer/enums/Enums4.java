package org.stjs.generator.writer.enums;

public enum Enums4 {
	a, b, c;

}
