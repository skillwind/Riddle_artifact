package org.stjs.generator.writer.fields;

public class Fields1 {
	public int x;
}
