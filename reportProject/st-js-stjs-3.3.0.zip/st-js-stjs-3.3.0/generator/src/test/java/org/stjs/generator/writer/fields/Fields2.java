package org.stjs.generator.writer.fields;

public class Fields2 {
	public int x = 2;
}
