package org.stjs.generator.writer.callSuper;

public class CallSuper4 extends SuperClass {
	public void instanceMethod2(String arg) {
		instanceMethod(arg);
	}
}
