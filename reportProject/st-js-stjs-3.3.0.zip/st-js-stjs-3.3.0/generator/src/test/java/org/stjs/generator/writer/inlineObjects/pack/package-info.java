@org.stjs.javascript.annotation.SyntheticType
package org.stjs.generator.writer.inlineObjects.pack;