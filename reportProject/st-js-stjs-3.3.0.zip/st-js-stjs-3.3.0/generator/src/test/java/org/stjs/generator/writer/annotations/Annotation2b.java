package org.stjs.generator.writer.annotations;

@MyAnnotations.WithSingleValue(4)
public class Annotation2b {

}
