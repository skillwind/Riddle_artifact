package org.stjs.generator.lib.string;

public class String6 {
	public static int main(String[] args) {
		return "abc".compareTo("b");
	}
}
