package org.stjs.generator.writer.innerTypes;

public class InnerTypes14 {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Inner.Enum value = Inner.Enum.a;
	}

	static class Inner {
		enum Enum {
			a, b, c
		};
	}
}
