package org.stjs.generator.exec.ints;

public class Ints3 {
	public int method() {
		return 3 / 2 + 1;
	}

	public static long main(String[] args) {
		return new Ints3().method();
	}
}
