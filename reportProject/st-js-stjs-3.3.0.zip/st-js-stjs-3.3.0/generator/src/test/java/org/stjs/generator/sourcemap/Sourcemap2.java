package org.stjs.generator.sourcemap;

public class Sourcemap2 {

	public void method2(Double n) {
		n.doubleValue();
	}

}
