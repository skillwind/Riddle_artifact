package org.stjs.generator.writer.inheritance;

public class Inheritance6 implements MyInterface4 {

}
