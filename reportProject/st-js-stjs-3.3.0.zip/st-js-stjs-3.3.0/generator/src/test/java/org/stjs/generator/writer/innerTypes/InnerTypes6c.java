package org.stjs.generator.writer.innerTypes;

public class InnerTypes6c {

	public int method() {
		return 0;
	}

	class InnerType {
		public void $invoke() {
			int m = InnerTypes6c.this.method();
		}
	}

}
