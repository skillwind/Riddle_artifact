package org.stjs.generator.writer.enums;

public interface Enums8 {
	public MyEnum method();

	public enum MyEnum {
		a, b, c;
	}
}
