@org.stjs.javascript.annotation.STJSBridge
package org.stjs.generator.writer.bridge.pack;