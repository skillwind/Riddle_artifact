package org.stjs.generator.writer.annotations;

public class Annotation4 {
	@MyAnnotations.WithArrayValue({"a", "b"})
	public int method() {
		return 0;
	}
}
