package org.stjs.generator.writer.bridge;

import org.stjs.javascript.annotation.STJSBridge;

public class Bridge6 {

	@STJSBridge
	public static class ActualBridge {
		public int variable;
	}
}
