package org.stjs.generator.deps;

public class Err2 extends Err1 {

}
