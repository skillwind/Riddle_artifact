package org.stjs.generator.writer.inheritance;

abstract public class Inheritance5<T> implements MyInterface3<T> {

}
