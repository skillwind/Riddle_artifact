package org.stjs.generator.writer.fields;

public class Fields10<T> {
	public T field;
}
