package org.stjs.generator.writer.bridge;

public class Bridge1 {
	public void method() {
		BridgeClass b = new BridgeClass();
	}
}
