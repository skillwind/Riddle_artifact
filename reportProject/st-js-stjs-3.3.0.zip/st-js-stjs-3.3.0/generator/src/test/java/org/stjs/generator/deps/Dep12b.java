package org.stjs.generator.deps;

public class Dep12b {
	public static class Inner {
		public static void newBuilder(){
			// Do nothing
		}
	}
}
