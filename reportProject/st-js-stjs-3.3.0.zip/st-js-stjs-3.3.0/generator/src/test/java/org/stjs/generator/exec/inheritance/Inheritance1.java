package org.stjs.generator.exec.inheritance;

import org.stjs.generator.exec.inheritance.Inheritance.B;

public class Inheritance1 {
	public static int main(String[] args) {
		B b = new B();
		return b.method2(1);
	}
}
