package org.stjs.generator.lib.string;

public class String10 {
	public static String main(String[] args) {
		return "abca".replaceAll("a", "x");
	}
}
