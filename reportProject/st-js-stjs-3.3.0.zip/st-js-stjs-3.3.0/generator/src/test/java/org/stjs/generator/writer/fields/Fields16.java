package org.stjs.generator.writer.fields;


public class Fields16 {

	public void method(String n) {
		Fields15 f = new Fields15();
		f.field = n;
	}

}
