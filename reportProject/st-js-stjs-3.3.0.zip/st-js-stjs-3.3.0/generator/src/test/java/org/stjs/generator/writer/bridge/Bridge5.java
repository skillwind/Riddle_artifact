package org.stjs.generator.writer.bridge;

import org.stjs.javascript.annotation.Template;

public class Bridge5 {
	@Template("get")
	public int getTest() {
		return 0;
	}
}