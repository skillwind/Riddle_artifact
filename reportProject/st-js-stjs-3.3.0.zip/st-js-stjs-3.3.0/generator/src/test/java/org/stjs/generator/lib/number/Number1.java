package org.stjs.generator.lib.number;

public class Number1 {
	public static int main(String[] args) {
		return Integer.parseInt("123");
	}
}
