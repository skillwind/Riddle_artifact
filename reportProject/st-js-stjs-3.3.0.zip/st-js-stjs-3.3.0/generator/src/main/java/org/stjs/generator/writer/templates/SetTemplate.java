package org.stjs.generator.writer.templates;

/**
 * the same as put
 * 
 * @author acraciun
 */
public class SetTemplate<JS> extends PutTemplate<JS> {

}