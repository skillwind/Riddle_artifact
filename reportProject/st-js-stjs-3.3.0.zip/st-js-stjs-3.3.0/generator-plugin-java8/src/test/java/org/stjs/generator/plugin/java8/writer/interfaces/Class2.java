package org.stjs.generator.plugin.java8.writer.interfaces;

public class Class2 implements Interface2 {
	public static int main(String[] args) {
		return new Class2().instanceMethod();
	}
}
