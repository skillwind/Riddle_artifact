package org.stjs.generator.plugin.java8.writer.interfaces;

public interface Interface2 {
	public default int instanceMethod() {
		return 1;
	}
}
