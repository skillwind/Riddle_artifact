package org.stjs.generator.plugin.java8.writer.switches;

public class Switch1 {
	public void method(String s) {
		switch (s) {
		case "abc":
			break;
		case "xyz":
			break;
		}
	}
}
