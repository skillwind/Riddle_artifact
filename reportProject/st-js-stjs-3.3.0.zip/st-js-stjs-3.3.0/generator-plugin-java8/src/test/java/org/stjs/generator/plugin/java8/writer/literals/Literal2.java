package org.stjs.generator.plugin.java8.writer.literals;

public class Literal2 {
	public static final int n = 0b0010_0101;
}
