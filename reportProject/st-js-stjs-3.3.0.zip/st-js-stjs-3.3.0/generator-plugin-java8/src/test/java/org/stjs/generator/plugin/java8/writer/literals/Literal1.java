package org.stjs.generator.plugin.java8.writer.literals;

public class Literal1 {
	public final static long n = 100_100L;
}
