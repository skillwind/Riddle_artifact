package org.stjs.generator.plugin.java8.writer.interfaces;

public interface Interface1 {
	public static int staticMethod() {
		return 1;
	}
}
