package us.codecraft.webmagic.downloader.selenium;

import java.util.ArrayList;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.DownloadedContent;
import com.gargoylesoftware.htmlunit.TopLevelWindow;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.WebResponseData;
import com.gargoylesoftware.htmlunit.util.NameValuePair;
//commons-io:commons-io:jar:2.2:compile
public class Test1 {
	public static void main(String[] args) {
		WebDriverPool pool = new WebDriverPool();
		pool.closeAll();
		
//		org.openqa.selenium.htmlunit.HtmlUnitDriver driver = new org.openqa.selenium.htmlunit.HtmlUnitDriver(BrowserVersion.CHROME);
//		driver.quit();
		
//		WebClient webClient = new WebClient(BrowserVersion.CHROME);
//		webClient.getTopLevelWindows().add(topLevelWindow(webClient));
		
//		WebResponse response = new WebResponse(webResponseData(),null,100);
//		response.cleanUp();
	}
	
	public static WebResponseData webResponseData() {
		return new WebResponseData(new DownloadedContent.OnFile(null,true),1,"test",new ArrayList<NameValuePair>());
	}
//	public static TopLevelWindow topLevelWindow(WebClient webClient) {
//		return new TopLevelWindow("test",webClient);
//	}
}
