package us.codecraft.webmagic.model.samples;

/**
 * @author code4crafter@gmail.com <br>
 * Date: 13-8-2 <br>
 * Time: 上午8:10 <br>
 */
public interface Blog {

    public String getTitle();

    public String getContent();
}
