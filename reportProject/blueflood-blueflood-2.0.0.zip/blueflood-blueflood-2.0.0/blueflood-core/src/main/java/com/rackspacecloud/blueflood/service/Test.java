package com.rackspacecloud.blueflood.service;

import java.util.HashSet;

public class Test {
	public static void main(String[] args) throws Exception {
		//2.7.1
		new com.rackspacecloud.blueflood.service.ZKShardLockManager("",new HashSet<Integer>()).shutdownUnsafe();
	}
}
