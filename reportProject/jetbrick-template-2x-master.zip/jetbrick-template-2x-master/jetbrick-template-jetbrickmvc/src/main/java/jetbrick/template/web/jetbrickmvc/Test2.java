package jetbrick.template.web.jetbrickmvc;
import jetbrick.template.parser.AstCodeVisitor;
import jetbrick.template.parser.ParserContext;
import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.tree.TerminalNodeImpl;

import jetbrick.template.runtime.parser.grammer.JetTemplateParser;
public class Test2 {
	public static void main(String[] args) {
		AstCodeVisitor astCodeVisitor0 = new AstCodeVisitor((ParserContext) null);
		JetTemplateParser.Directive_define_expressionContext jetTemplateParser_Directive_define_expressionContext0 = 
				new JetTemplateParser.Directive_define_expressionContext(
						null, 3387);
		jetTemplateParser_Directive_define_expressionContext0.addAnyChild(new TerminalNodeImpl(new org.antlr.v4.runtime.tree.pattern.RuleTagToken("test",82)));
		// Undeclared exception!
			astCodeVisitor0.visitDirective_define_expression(jetTemplateParser_Directive_define_expressionContext0);
	}
//	public static ParserRuleContext ParserRuleContext() {
////		return null;
//		ParserRuleContext context = new ParserRuleContext();
//		context.addAnyChild(new TerminalNodeImpl(new org.antlr.v4.runtime.tree.pattern.RuleTagToken("test",82)));
//		return context;
//	}
}
