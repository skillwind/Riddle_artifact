package com.vip.saturn.job.console.domain;

/**
 * @author hebelala
 */
public class JobMode {

	public static final String SYSTEM_PREFIX = "system";

	public static final String system_scale = SYSTEM_PREFIX + "_scale";

}
