package com.vip.saturn.job.console.service.impl.marathon.entity;

import java.util.List;

/**
 * @author hebelala
 */
public class Tasks {

	private List<Task> taskList;

	public List<Task> getTaskList() {
		return taskList;
	}

	public void setTaskList(List<Task> taskList) {
		this.taskList = taskList;
	}
}
