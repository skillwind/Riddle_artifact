package com.vip.saturn.job.console.domain;

/**
 * @author hebelala
 */
public enum ExecutorProvidedStatus {

	ONLINE,
	OFFLINE,
	DELETED

}
