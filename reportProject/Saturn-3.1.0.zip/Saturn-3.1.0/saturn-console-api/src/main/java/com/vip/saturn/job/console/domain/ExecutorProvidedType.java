package com.vip.saturn.job.console.domain;

/**
 * @author hebelala
 */
public enum ExecutorProvidedType {

	DOCKER,
	PHYSICAL

}
