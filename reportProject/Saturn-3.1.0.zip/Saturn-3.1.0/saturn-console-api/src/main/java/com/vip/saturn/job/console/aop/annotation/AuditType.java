package com.vip.saturn.job.console.aop.annotation;

public enum AuditType {
	// GUI API audit log
	WEB,
	// REST API audit log
	REST;
}
