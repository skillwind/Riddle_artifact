package com.vip.saturn.job.console.utils;

/**
 * @author chembo.huang
 */
public class ResetCountType {

	public static final String RESET_ANALYSE = "a";

	public static final String RESET_SERVERS = "s";

}
