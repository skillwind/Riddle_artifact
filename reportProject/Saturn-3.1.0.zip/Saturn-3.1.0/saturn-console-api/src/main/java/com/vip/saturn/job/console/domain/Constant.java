package com.vip.saturn.job.console.domain;

public class Constant {
    public static final String CHARSET_UTF8 = "UTF-8";
}
