package com.vip.saturn.job.console.service.impl.marathon.entity;

/**
 * @author hebelala
 */
public class WrapperApp {

	private App app;

	public App getApp() {
		return app;
	}

	public void setApp(App app) {
		this.app = app;
	}
}
