package com.vip.saturn.job.console.domain;

public class JobConfigMeta {

	private String name;

	private String desc_zh;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesc_zh() {
		return desc_zh;
	}

	public void setDesc_zh(String desc_zh) {
		this.desc_zh = desc_zh;
	}
}
