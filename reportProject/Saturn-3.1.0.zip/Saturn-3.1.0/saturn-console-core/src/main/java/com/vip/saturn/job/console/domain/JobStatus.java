/**
 * 
 */
package com.vip.saturn.job.console.domain;

/**
 * @author chembo.huang
 *
 */
public enum JobStatus {
	READY, STOPPED, RUNNING, STOPPING,
}
