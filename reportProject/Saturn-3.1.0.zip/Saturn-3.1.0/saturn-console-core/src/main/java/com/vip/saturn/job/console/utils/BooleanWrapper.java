/**
 * 
 */
package com.vip.saturn.job.console.utils;

/**
 * @author chembo.huang
 *
 */
public class BooleanWrapper {

	private boolean value;

	public boolean isValue() {
		return this.value;
	}

	public void setValue(boolean value) {
		this.value = value;
	}

	public BooleanWrapper(boolean value) {
		this.value = value;
	}
}
