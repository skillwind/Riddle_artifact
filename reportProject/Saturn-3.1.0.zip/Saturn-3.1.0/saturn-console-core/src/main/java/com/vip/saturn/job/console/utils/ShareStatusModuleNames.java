package com.vip.saturn.job.console.utils;

/**
 * 
 * @author hebelala
 *
 */
public class ShareStatusModuleNames {
	
	public static final String MOVE_NAMESPACE_BATCH_STATUS = "MOVE_NAMESPACE_BATCH_STATUS";
	public static final String EXPORT_JOB_CONFIG_PAGE_STATUS = "EXPORT_JOB_CONFIG_PAGE_STATUS";

}
