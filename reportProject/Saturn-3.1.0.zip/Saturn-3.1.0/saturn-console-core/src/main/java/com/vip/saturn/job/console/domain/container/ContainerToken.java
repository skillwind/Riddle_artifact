package com.vip.saturn.job.console.domain.container;

import java.util.Map;

/**
 * @author hebelala
 */
public class ContainerToken {

	private Map<String, String> keyValue;

	public Map<String, String> getKeyValue() {
		return keyValue;
	}

	public void setKeyValue(Map<String, String> keyValue) {
		this.keyValue = keyValue;
	}
}
