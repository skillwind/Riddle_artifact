package com.vip.saturn.demo.service;

public class DemoService {

	public void execute() {
		// do business service
		System.out.println(".....................");
	}

}
