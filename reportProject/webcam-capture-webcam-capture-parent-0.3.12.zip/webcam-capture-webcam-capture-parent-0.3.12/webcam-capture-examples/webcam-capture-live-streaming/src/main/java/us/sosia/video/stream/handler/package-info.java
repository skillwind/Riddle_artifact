/**
 * 
 */
/**
 * @author kerr
 *
 */
package us.sosia.video.stream.handler;