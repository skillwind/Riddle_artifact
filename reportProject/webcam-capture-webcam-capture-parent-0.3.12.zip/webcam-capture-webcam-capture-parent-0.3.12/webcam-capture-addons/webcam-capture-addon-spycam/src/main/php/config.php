<?php

$SPY_CONFIG = array(

	/**
	 * Password used to authenticate client.
	 */
	'passwd' => 'test1234',
	
	/**
	 * Directory where pictures will be stored.
	 */
	'dir' => 'uploads',
	
);