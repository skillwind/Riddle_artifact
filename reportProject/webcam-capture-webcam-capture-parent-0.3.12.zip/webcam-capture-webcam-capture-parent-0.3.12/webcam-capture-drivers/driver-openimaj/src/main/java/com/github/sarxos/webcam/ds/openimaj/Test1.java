package com.github.sarxos.webcam.ds.openimaj;

import java.awt.Dimension;

public class Test1 {
	public static void main(String[] args) {
		OpenImajDevice device = new OpenImajDevice(null);
//		device.setResolution(Dimension());
		device.open();
	}
	public static Dimension Dimension( ) {
		return new Dimension(5,5);
	}
}
