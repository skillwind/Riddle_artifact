package com.github.sarxos.webcam.ds.openimaj;
import org.bridj.Pointer;
import org.bridj.PointerIO;
import org.bridj.Pointer;
import org.bridj.TypedPointer;
public class Test2 {
public static void main(String[] args) {
    Class<TypedPointer> class0 = TypedPointer.class;
    // Undeclared exception!
      Pointer.allocateTypedPointers(class0, 31L);
  
}
}
