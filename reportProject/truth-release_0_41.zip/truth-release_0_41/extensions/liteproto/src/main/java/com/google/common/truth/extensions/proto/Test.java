package com.google.common.truth.extensions.proto;
import com.google.protobuf.UnknownFieldSet;
public class Test {
	public static void main(String[] args) {
//		Expect expect = Expect.create();
//		FailureMetadata failureMetadata = expect.
//		LiteProtoSubject subject = new LiteProtoSubject(failureMetadata, null);
//		subject.isEqualTo(null);
		
//		LiteProtoSubject subject = LiteProtoSubject.liteProtos().createSubject(null, null);
		LiteProtoTruth.assertThat(UnknownFieldSet.getDefaultInstance()).isEqualTo(new Object());
		
	}
}
