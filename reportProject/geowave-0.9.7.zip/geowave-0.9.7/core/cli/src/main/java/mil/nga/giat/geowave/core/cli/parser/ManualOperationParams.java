/*******************************************************************************
 * Copyright (c) 2013-2017 Contributors to the Eclipse Foundation
 * 
 * See the NOTICE file distributed with this work for additional
 * information regarding copyright ownership.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Apache License,
 * Version 2.0 which accompanies this distribution and is available at
 * http://www.apache.org/licenses/LICENSE-2.0.txt
 ******************************************************************************/
package mil.nga.giat.geowave.core.cli.parser;

import java.util.HashMap;
import java.util.Map;

import mil.nga.giat.geowave.core.cli.api.Operation;
import mil.nga.giat.geowave.core.cli.api.OperationParams;

public class ManualOperationParams implements
		OperationParams
{

	private final Map<String, Object> context = new HashMap<String, Object>();

	@Override
	public Map<String, Operation> getOperationMap() {
		return new HashMap<String, Operation>();
	}

	@Override
	public Map<String, Object> getContext() {
		return context;
	}
}
