package mil.nga.giat.geowave.core.cli.api;

public enum ServiceStatus {
	OK,
	NOT_FOUND,
	DUPLICATE,
	INTERNAL_ERROR
}
