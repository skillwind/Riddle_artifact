Before your contribution can be accepted by the project, you need to create an Eclipse Foundation 
account and electronically sign the Eclipse Contributor Agreement (ECA).

- http://www.eclipse.org/legal/ECA.php

For more information on contributing to GeoWave, please see our developer guide here:

- http://locationtech.github.io/geowave/devguide.html#contributions
