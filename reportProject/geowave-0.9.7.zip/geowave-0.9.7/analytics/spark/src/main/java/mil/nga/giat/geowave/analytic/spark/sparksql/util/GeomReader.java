package mil.nga.giat.geowave.analytic.spark.sparksql.util;

import java.io.Serializable;

import com.vividsolutions.jts.io.WKTReader;

public class GeomReader extends
		WKTReader implements
		Serializable
{

}
