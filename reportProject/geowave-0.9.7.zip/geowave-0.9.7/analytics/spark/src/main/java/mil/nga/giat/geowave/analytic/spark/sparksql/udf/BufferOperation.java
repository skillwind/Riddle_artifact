package mil.nga.giat.geowave.analytic.spark.sparksql.udf;

public interface BufferOperation
{
	public double getBufferAmount();
}
