import org.openqa.selenium.safari.SafariDriver;

public class Test {
	public static void main(String[] args) {
		new SafariDriver();
	}
}
