<!-- Love ff4j? Please consider supporting our collective:
👉  https://opencollective.com/ff4j/donate -->