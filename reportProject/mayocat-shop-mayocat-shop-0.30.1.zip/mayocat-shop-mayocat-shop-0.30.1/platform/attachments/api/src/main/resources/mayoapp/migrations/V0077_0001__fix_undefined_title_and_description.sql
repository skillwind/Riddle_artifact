UPDATE attachment SET title = NULL WHERE title = 'undefined';
UPDATE attachment SET description = NULL WHERE description = 'undefined';