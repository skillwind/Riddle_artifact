ALTER TABLE tenant
ADD COLUMN description text;