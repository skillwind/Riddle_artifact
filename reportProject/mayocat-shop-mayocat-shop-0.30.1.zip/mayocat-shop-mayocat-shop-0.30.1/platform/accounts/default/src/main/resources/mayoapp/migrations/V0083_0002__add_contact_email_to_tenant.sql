ALTER TABLE tenant
ADD COLUMN contact_email character varying(255);