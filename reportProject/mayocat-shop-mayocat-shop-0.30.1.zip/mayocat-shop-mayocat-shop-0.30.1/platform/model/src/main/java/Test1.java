import org.mayocat.model.AttachmentData;

public class Test1 {
	public static void main(String[] args) {
		new AttachmentData(null);
	}
}
