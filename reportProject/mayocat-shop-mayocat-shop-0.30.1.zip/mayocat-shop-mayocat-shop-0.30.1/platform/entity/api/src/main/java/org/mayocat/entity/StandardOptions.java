/*
 * Copyright (c) 2012, Mayocat <hello@mayocat.org>
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */
package org.mayocat.entity;

/**
 * @version $Id: 760bcc04a7cb00ca47fc898899d198462128fca1 $
 */
public enum StandardOptions implements LoadingOption
{
    LOCALIZE
}
